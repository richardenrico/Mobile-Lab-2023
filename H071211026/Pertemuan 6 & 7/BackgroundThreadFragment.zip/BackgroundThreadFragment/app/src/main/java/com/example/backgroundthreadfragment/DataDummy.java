package com.example.backgroundthreadfragment;

import java.util.ArrayList;
import java.util.List;

public class DataDummy {

    public static ArrayList<ModelDummy> dataDummy = new ArrayList<>();

}
